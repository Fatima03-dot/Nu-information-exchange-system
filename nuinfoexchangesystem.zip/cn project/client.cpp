// client.cpp
// Compile: g++ -std=c++17 client.cpp -o client -pthread
// Usage: ./client <CampusName> <Password> <ServerIP>
// Example: ./client Lahore NU-LHR-123 127.0.0.1

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <chrono>
#include <cstring>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>

constexpr int SERVER_TCP_PORT = 5000;
constexpr int SERVER_UDP_PORT = 6000;
constexpr int BUFFER_SIZE = 4096;

std::mutex cout_m;
void log(const std::string& s) {
	std::lock_guard<std::mutex> g(cout_m);
	std::cout << s << std::endl;
}

int tcp_sock = -1;
int udp_sock = -1;
std::string campus_name, campus_pass;
std::atomic<bool> running{ true };

// helper to send TCP
void tcp_send(const std::string& msg) {
	send(tcp_sock, msg.c_str(), msg.size(), 0);
}

// Thread: listen for TCP messages from server (deliveries/errors)
void tcp_reader() {
	char buf[BUFFER_SIZE];
	while (running) {
		ssize_t n = recv(tcp_sock, buf, sizeof(buf) - 1, 0);
		if (n <= 0) {
			log("Disconnected from server.");
			running = false;
			break;
		}
		buf[n] = '\0';
		std::string s(buf);
		log("[TCP RECV] " + s);
	}
}

// Thread: periodically send UDP heartbeat to server
void heartbeat_thread(const std::string server_ip) {
	sockaddr_in server_addr{};
	server_addr.sin_family = AF_INET;
	inet_pton(AF_INET, server_ip.c_str(), &server_addr.sin_addr);
	server_addr.sin_port = htons(SERVER_UDP_PORT);

	while (running) {
		std::stringstream ss;
		long ts = std::time(nullptr);
		ss << "HEARTBEAT;Campus:" << campus_name << ";TS:" << ts;
		std::string pkt = ss.str();
		sendto(udp_sock, pkt.c_str(), pkt.size(), 0, (sockaddr*)&server_addr, sizeof(server_addr));
		std::this_thread::sleep_for(std::chrono::seconds(10));
	}
}

// Thread: listen for UDP broadcasts (from server)
void udp_listener() {
	char buf[BUFFER_SIZE];
	while (running) {
		sockaddr_in src{};
		socklen_t sl = sizeof(src);
		ssize_t n = recvfrom(udp_sock, buf, sizeof(buf) - 1, 0, (sockaddr*)&src, &sl);
		if (n <= 0) continue;
		buf[n] = '\0';
		std::string s(buf);
		log("[UDP RECV] " + s);
	}
}

int main(int argc, char** argv) {
	if (argc < 4) {
		std::cerr << "Usage: " << argv[0] << " <CampusName> <Password> <ServerIP>\n";
		return 1;
	}
	campus_name = argv[1];
	campus_pass = argv[2];
	std::string server_ip = argv[3];

	// create TCP socket and connect
	tcp_sock = socket(AF_INET, SOCK_STREAM, 0);
	if (tcp_sock < 0) { perror("tcp socket"); return 1; }
	sockaddr_in servaddr{};
	servaddr.sin_family = AF_INET;
	inet_pton(AF_INET, server_ip.c_str(), &servaddr.sin_addr);
	servaddr.sin_port = htons(SERVER_TCP_PORT);
	if (connect(tcp_sock, (sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
		perror("connect");
		close(tcp_sock); return 1;
	}
	log("Connected (TCP) to server.");

	// create UDP socket (bind to ephemeral port so server can reply to it)
	udp_sock = socket(AF_INET, SOCK_DGRAM, 0);
	if (udp_sock < 0) { perror("udp socket"); return 1; }
	sockaddr_in myaddr{};
	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = INADDR_ANY;
	myaddr.sin_port = htons(0); // ephemeral
	if (bind(udp_sock, (sockaddr*)&myaddr, sizeof(myaddr)) < 0) {
		perror("udp bind");
		close(udp_sock); return 1;
	}

	// Authentication
	std::stringstream auth;
	auth << "AUTH;Campus:" << campus_name << ";Pass:" << campus_pass << "\n";
	tcp_send(auth.str());

	// start threads
	std::thread tr(tcp_reader);
	std::thread uh(udp_listener);
	std::thread hb(heartbeat_thread, server_ip);

	// Console UI
	while (running) {
		std::cout << "\nMenu:\n1) send message\n2) quit\nChoose: ";
		int choice;
		if (!(std::cin >> choice)) break;
		if (choice == 1) {
			std::string target, dept;
			std::string msg;
			std::cout << "TargetCampus: "; std::cin >> target;
			std::cout << "TargetDept: "; std::cin >> dept;
			std::cin.ignore();
			std::cout << "Message: "; std::getline(std::cin, msg);
			std::stringstream ss;
			ss << "MSG;From:" << campus_name << ";To:" << target << ";Dept:" << dept << ";Body:" << msg << "\n";
			tcp_send(ss.str());
		}
		else if (choice == 2) {
			running = false;
			break;
		}
		else {
			std::cout << "Unknown choice\n";
		}
	}

	// cleanup
	close(tcp_sock);
	close(udp_sock);
	if (tr.joinable()) tr.join();
	if (uh.joinable()) uh.detach();
	if (hb.joinable()) hb.detach();
	return 0;
}